/** Automatically generated file. DO NOT MODIFY */
package com.absolute.android_auto_update_ecl;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}